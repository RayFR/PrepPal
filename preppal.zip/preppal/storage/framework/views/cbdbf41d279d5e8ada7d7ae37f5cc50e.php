<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<main class="container main-content">

  <nav class="pp-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span>/</span>
    <a href="<?php echo e(route('store')); ?>">Store</a>
    <span>/</span>
    <span class="pp-crumb-current"><?php echo e($product->name); ?></span>
  </nav>

  <div class="pp-pdp">

    
    <section class="pp-pdp-left">
      <div class="pp-image-frame">
        <img
          src="<?php echo e(asset($product->image_path)); ?>"
          alt="<?php echo e($product->name); ?>"
          class="pp-product-img"
        >
      </div>
    </section>

    
    <aside class="pp-pdp-right">
      <h1 class="pp-title"><?php echo e($product->name); ?></h1>
      <p class="pp-subtitle"><?php echo e($product->category === 'meal' ? 'Meal Prep Plan' : 'Supplement'); ?></p>

      <div class="pp-rating">
        <span class="pp-stars">★★★★★</span>
        <span class="pp-rating-text">4.8 (128 reviews)</span>
      </div>

      <div class="pp-price-row">
        <div class="pp-price">
          £<?php echo e(number_format($product->price, 2)); ?>

          <?php if($product->category === 'meal'): ?>
            <span class="pp-per">/ week</span>
          <?php endif; ?>
        </div>
        <div class="pp-stock">In stock</div>
      </div>

      <ul class="pp-benefits">
        <?php if($product->category === 'meal'): ?>
          <li>Goal-based weekly plan</li>
          <li>Macro-friendly & portion-controlled</li>
          <li>Pause or cancel anytime</li>
        <?php else: ?>
          <li>Pairs well with your meal plan</li>
          <li>Routine-friendly dosing</li>
          <li>Great value per serving</li>
        <?php endif; ?>
      </ul>

      <div class="pp-actions">
        <div class="pp-qty">
          <button type="button" class="pp-qty-btn" data-qty="-1" aria-label="Decrease quantity">−</button>
          <input class="pp-qty-input" type="number" min="1" value="1">
          <button type="button" class="pp-qty-btn" data-qty="+1" aria-label="Increase quantity">+</button>
        </div>

        
        <button
          type="button"
          class="cta pp-add add-to-cart"
          data-id="<?php echo e($product->id); ?>"
          data-name="<?php echo e($product->name); ?>"
          data-price="<?php echo e($product->price); ?>"
          data-image="<?php echo e(asset($product->image_path)); ?>"
          data-qty="1"
        >
          Add to cart
        </button>
      </div>

      <div class="pp-trust">
        <div class="pp-trust-item">✅ Quality checked</div>
        <div class="pp-trust-item">🚚 Fast UK delivery</div>
        <div class="pp-trust-item">🔒 Secure checkout</div>
      </div>

      <div class="pp-ship">
        <div class="pp-ship-row"><span>🚚</span> <strong>Delivery:</strong>&nbsp;2–4 working days (UK)</div>
        <div class="pp-ship-row"><span>↩️</span> <strong>Returns:</strong>&nbsp;14-day returns on unopened items</div>
      </div>

      <div class="pp-accordion">
        <details open>
          <summary>Description</summary>
          <p><?php echo e($product->description); ?></p>
        </details>

        <details>
          <summary>How to use</summary>
          <p>
            <?php if($product->category === 'meal'): ?>
              Choose your plan, order weekly, track progress — pause/cancel before next billing.
            <?php else: ?>
              Follow label directions. Use consistently and stay hydrated.
            <?php endif; ?>
          </p>
        </details>

        <details>
          <summary>FAQs</summary>
          <p><strong>When will my order arrive?</strong><br>Usually 2–4 working days.</p>
          <p><strong>Can I cancel a plan?</strong><br>Yes, before your next billing.</p>
        </details>
      </div>
    </aside>

  </div>
</main>


<script>
  document.addEventListener('DOMContentLoaded', () => {
    const qtyWrap = document.querySelector('.pp-qty');
    const qtyInput = document.querySelector('.pp-qty-input');
    const addBtn = document.querySelector('.pp-add.add-to-cart');

    if (!qtyWrap || !qtyInput || !addBtn) return;

    const clampQty = (n) => {
      const v = Number.isFinite(n) ? n : 1;
      return Math.max(1, Math.floor(v));
    };

    const sync = () => {
      addBtn.dataset.qty = String(clampQty(parseInt(qtyInput.value || '1', 10)));
    };

    qtyWrap.addEventListener('click', (e) => {
      const btn = e.target.closest('.pp-qty-btn');
      if (!btn) return;

      const delta = btn.dataset.qty === '+1' ? 1 : -1;
      const current = clampQty(parseInt(qtyInput.value || '1', 10));
      qtyInput.value = String(clampQty(current + delta));
      sync();
    });

    qtyInput.addEventListener('input', sync);
    qtyInput.addEventListener('change', sync);

    sync();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\agraj\Documents\GitHub\PrepPal\preppal\resources\views/frontend/product-show.blade.php ENDPATH**/ ?>