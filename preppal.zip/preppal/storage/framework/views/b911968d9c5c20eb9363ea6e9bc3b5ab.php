<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', config('app.name', 'PrepPal')); ?></title>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
</head>

<body>

    <header class="nav">
        <div class="container nav-inner">

            <a class="brand" href="<?php echo e(route('home')); ?>">
                <span class="brand-badge"></span>
            </a>

            <nav class="nav-links">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <a href="<?php echo e(route('contact.index')); ?>">Contact</a>

                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('store')); ?>">Store</a>
                    <a href="<?php echo e(route('calculator')); ?>">Calculator</a>
                    <span id="cartDisplay">Cart (0)</span>
                    <span>Hi, <?php echo e(auth()->user()->name); ?></span>

                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="logout-btn">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                <?php endif; ?>

                <button id="themeToggle" class="theme-toggle">☀️</button>
            </nav>

        </div>
    </header>

    <main style="padding-top: 2rem;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- GLOBAL CART PANEL (used by ALL pages) -->
    <div id="cartPanel" class="cart-panel" aria-hidden="true">

        <h3>Your Cart</h3>
        <p id="cartSummary">You have 0 items in your cart.</p>

        <ul id="cartItems" class="cart-items"></ul>

        <p id="cartTotal" class="cart-total">Total: £0.00</p>

        <div class="cart-actions">
            <button type="button" class="cart-btn cart-clear">Clear</button>
            <button type="button" class="cart-btn cart-checkout">Checkout</button>
            <button type="button" class="cart-btn cart-close">Close</button>
        </div>

    </div>

        <!-- Scripts loaded after HTML -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/store.js')); ?>"></script>
    <script src="<?php echo e(asset('js/checkout.js')); ?>"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\Users\agraj\Documents\GitHub\PrepPal\preppal\resources\views/layouts/app.blade.php ENDPATH**/ ?>