<!--
  Students & IDs: Agraj Khanna (240195519)/ Gurpreet Singh Sidhu (230237915)/ Musab Ahmed Rashid (230084799)
  File: admin.html
  Description: Admin landing page (links to admin sections)
  Date: Nov 2025
-->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet"> <!--Adding Poppins font (Gurpreet Singh Sidhu / 230237915 ID)-->  <!--Fixing Poppins text error (Agraj Khanna / 240195519 ID)--> 
  <link rel="stylesheet" href="css/style.css" />
</head>

<script>
  (function () {
    try {
      var raw = localStorage.getItem('preppal_currentUser');
      if (!raw) { window.location.href = 'login.html'; return; }
      var user = JSON.parse(raw);
      if (!user || !user.isAdmin) {
        window.location.href = 'login.html';
      }
    } catch (e) {
      window.location.href = 'login.html';
    }
  })();
</script>


<body>
<header class="nav">
  <div class="container nav-inner">
    <a class="brand" href="index.html"><span class="brand-badge"></span></a>
    <nav class="nav-links">
      <!-- Public links (always available) -->
      <a href="index.html">Home</a>
      <a href="calculator.html">Calculator</a>
      <a href="store.html">Meals</a>

      <!-- Admin-only links (JS will hide/show, but page itself is admin-guarded anyway) -->
      <a href="admin.html" class="nav-admin-only active">Admin Home</a>
      <a href="dashboard.html" class="nav-admin-only">Dashboard</a>

      <span id="cartDisplay">Cart (0)</span>
      <button id="themeToggle" type="button" class="theme-toggle" aria-label="Toggle theme">☀️</button>
      <a class="cta" href="login.html" id="authButton">Log Out</a>
    </nav>
  </div>
</header>


  <!-- Mini cart panel (shared across all pages) (Gurpreet Singh Sidhu - 230237915 ID)-->
<div id="cartPanel" class="cart-panel" aria-hidden="true">
  <h3>Your Cart</h3>
  <p id="cartSummary">You have 0 items in your cart.</p>

  <ul id="cartItems" class="cart-items">
  </ul>

  <p id="cartTotal" class="cart-total">Total: £0.00</p>

  <div class="cart-actions">
    <button type="button" class="cart-btn cart-clear">Clear Cart</button>
    <button type="button" class="cart-btn cart-checkout">Checkout</button>
    <button type="button" class="cart-btn cart-close">Close</button>
  </div>
</div>

<main class="container main-content">
  <h2>Admin Control</h2>
  <p>Quick links to the admin tasks you need to manage.</p>

  <div class="admin-dashboard" style="margin-top:1.25rem;">
    <div class="card">
      <h3>Inventory</h3>
      <p><a href="store.html">Manage meals &amp; supplements</a></p>
    </div>
    <div class="card">
      <h3>Orders</h3>
      <p><a href="admin-orders.html">View recent orders</a></p>
    </div>
    <div class="card">
      <h3>Users</h3>
      <p><a href="admin-users.html">Manage user accounts</a></p>
    </div>
  </div>
</main>


  <footer class="footer">
    <div class="container">© <span id="year"></span> PrepPal — Eat better, live easier.</div>
  </footer>

  <script src="js/app.js"></script>
  <script src="js/store.js"></script> <!--Deleted Section Making It Neater (Agraj Khanna/240195519 ID)-->
</body>
</html>
